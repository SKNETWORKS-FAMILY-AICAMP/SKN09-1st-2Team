# 월별 선 그래프
import streamlit as st 
import pandas as pd 
from sql_dataframe_read import sql_read # 

# 월별 데이터를 가지고 와서 사용

#st.title("국내 5대사의 친환경 자동차 월별 판매량")

sql_data = sql_read()

print(f"길이: {len(sql_data)}")

#데이터프레임으로 변환 # 다른 데이터라 거기에 맞게 해야함
df = pd.DataFrame(sql_data, columns=["brand", "fuel_name", "model_name", "sale_month", "sale_count"])

# 데이터를 스트림릿에서 확인
st.dataframe(df, use_container_width=True)

# 선 그래프 그리기 나중에 월 데이터로 변경
st.line_chart(df.set_index("sale_month")["sale_count"])